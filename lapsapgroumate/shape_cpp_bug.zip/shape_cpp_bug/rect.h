#include "shape.h"
#include <iostream>
#include <string>
#ifndef RECT_H
#define RECT_H

using namespace std;

class Rect:public Shape
{
	public: Rectangle(int, int[]);
			float area();
	protected:
};

#endif
