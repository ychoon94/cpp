#include "shape.h"
#include <iostream>
#include <string>
#ifndef TRIANGLE_H
#define TRIANGLE_H

using namespace std;

class Triangle : public Shape
{
	public:Triangle(int,int[]);
		
	protected:
};

#endif
