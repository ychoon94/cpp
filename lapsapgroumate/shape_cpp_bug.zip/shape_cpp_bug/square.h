#include "shape.h"
#include <iostream>
#include <string>
#ifndef SQUARE_H
#define SQUARE_H

using namespace std;

class Square:public Shape
{
	public:Square(int,int[]);
			float area();
	protected:
};

#endif
